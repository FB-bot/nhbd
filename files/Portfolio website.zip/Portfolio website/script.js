// মোবাইল মেনু টগল
const menuToggle = document.getElementById('menuToggle');
const navMenu = document.getElementById('navMenu');
menuToggle.addEventListener('click', () => {
  navMenu.classList.toggle('active');
});
// মেনু বন্ধ করার জন্য লিংক ক্লিক করলে
document.querySelectorAll('.nav-menu a').forEach(link => {
  link.addEventListener('click', () => {
    navMenu.classList.remove('active');
  });
});

// ডার্ক মোড টগল (মোবাইল ও ডেস্কটপ)
const darkToggle = document.getElementById('darkToggleMobile');
const body = document.body;
if (localStorage.getItem('theme') === 'dark') body.classList.add('dark');
darkToggle.addEventListener('click', () => {
  body.classList.toggle('dark');
  localStorage.setItem('theme', body.classList.contains('dark') ? 'dark' : 'light');
  const icon = darkToggle.querySelector('i');
  if(body.classList.contains('dark')) {
    icon.classList.remove('fa-moon');
    icon.classList.add('fa-sun');
  } else {
    icon.classList.remove('fa-sun');
    icon.classList.add('fa-moon');
  }
});

// প্রগ্রেস বার অ্যানিমেশন (স্ক্রল করলে)
const progressFills = document.querySelectorAll('.progress-fill');
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if(entry.isIntersecting) {
      const width = entry.target.getAttribute('data-width');
      if(width && !entry.target.style.width) {
        entry.target.style.width = width + '%';
      }
    }
  });
}, { threshold: 0.3 });
progressFills.forEach(bar => observer.observe(bar));

// স্ক্রল টু টপ বাটন
const scrollBtn = document.getElementById('scrollTopBtn');
window.addEventListener('scroll', () => {
  if(window.scrollY > 400) scrollBtn.classList.add('show');
  else scrollBtn.classList.remove('show');
});
scrollBtn.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

// ডাউনলোড সিভি ডেমো
document.getElementById('cvDownload')?.addEventListener('click', (e) => {
  e.preventDefault();
  alert('✅ সিভি ডাউনলোড ডেমো: Alex_CV_2025.pdf');
});

// কন্টাক্ট ফর্ম সাবমিট
document.getElementById('contactForm')?.addEventListener('submit', (e) => {
  e.preventDefault();
  alert('📩 আপনার মেসেজ সফলভাবে পাঠানো হয়েছে। শীঘ্রই যোগাযোগ করব।');
  e.target.reset();
});

// স্মুথ স্ক্রল (অ্যাঙ্কর লিংক)
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    const targetId = this.getAttribute('href');
    if(targetId === "#" || targetId === "") return;
    const target = document.querySelector(targetId);
    if(target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});